package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MainController {
	
	private SzamologepService SzamologepService = new SzamologepService();
	
	@GetMapping("/")
	public String barmi() {
		return "hello vazze";
	}
	
	@GetMapping(path="/szamologep")
	public double szamologep(
		@RequestParam("a") int a,
		@RequestParam("b") int b,
		@RequestParam("operator") String operator) {
		
		return SzamologepService.szamol(a,  b, operator);
	}
	
	@GetMapping(path="/szamologep-rest", consumes="application/json", produces="application/json")
	public double calculatorRest(@RequestBody CalculatorDto calculatorDto) {
		
		return SzamologepService.szamol(
			calculatorDto.getA(),
			calculatorDto.getB(),
			calculatorDto.getOperator());
	}

}

/*
 * Content-Type: application/json
 */


/*
JSON:
{
	"a": 4,
	"b": 7,
	"operator": "+"
}
*/